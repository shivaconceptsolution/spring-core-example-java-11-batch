package factoryinjector;

public class B implements Printable{

	@Override
	public void print() {
		System.out.println("B");
		
	}

}
