package dep;

interface MessageService {
	void sendMessage(String msg, String rec);

}
