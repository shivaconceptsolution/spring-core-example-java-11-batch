package factoryinjector;

public class A implements Printable{

	@Override
	public void print() {
		System.out.println("A Print");
		
	}

}
