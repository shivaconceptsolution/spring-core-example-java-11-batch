package factoryinjector;

public interface Printable {
void print();
}
