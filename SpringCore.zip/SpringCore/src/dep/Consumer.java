package dep;

interface Consumer {
	void processMessages(String msg, String rec);
	
}
