
public class EnumExample {
    enum weekdays
    {
    	sunday,monday,tuesday,friday;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//System.out.print(weekdays.sunday);
		
		for(weekdays w: weekdays.values())
		{
			System.out.println(w);
		}
		
		System.out.print(weekdays.sunday.ordinal());

	}

}
