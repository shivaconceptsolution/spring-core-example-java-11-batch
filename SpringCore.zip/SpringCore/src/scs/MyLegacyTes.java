package scs;

public class MyLegacyTes {

	public static void main(String[] args) {
		MyApplication obj = new MyApplication(new EmailService());
		obj.processMessages("sender", "reciver");

	}

}
