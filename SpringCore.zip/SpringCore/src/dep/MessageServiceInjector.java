package dep;

public interface MessageServiceInjector {
	public Consumer getConsumer();
}
