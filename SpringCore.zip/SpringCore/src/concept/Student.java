package concept;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Student {
private String name;
private int age;
List ls;
Map mp;
Student()
{
	this.name="xyz";
}
Student(String name)
{
	this.name=name;
}
Student(String name, int age)
{
	this.name=name;
	this.age=age;
}
Student(String name,List ls)
{
	this.name=name;
	this.ls=ls;
}

Student(Map mp)
{
	this.mp=mp;
	
}
Student(String name,Map mp)
{
	this.name=name;
	this.mp=mp;
	
}
public String toString(){
	return "name is "+name + "Age is "+age;
}
public void show()
{
	System.out.println("name is "+name);
	for(Object o:ls)
	{
		System.out.println(o);
	}
}
public void showMapData()
{
	System.out.println("Name is "+name);
	System.out.println("Data of Map is");
	Set<Map.Entry<String,String>> se = mp.entrySet();
	for(Map.Entry<String,String> s : se)
	{
		System.out.println(s.getKey() + " "+s.getValue());
	}
}

}
